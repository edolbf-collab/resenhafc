-- Resenha FC Beta 1.0 Build 124 — healthcheck
select channel, version, build, database_build, edge_build, active, mandatory, notes
from public.app_releases
where channel = 'beta'
order by build desc
limit 5;

select
  to_regprocedure('public.platform_push_status_list(integer)') as push_status_rpc,
  to_regprocedure('public.platform_beta_summary()') as beta_summary_rpc,
  to_regprocedure('public.platform_operational_export(integer,integer)') as operational_export_rpc;

select
  count(*) filter (where ba.status='active' and ba.user_id is not null and exists(select 1 from public.push_subscriptions ps where ps.user_id=ba.user_id and ps.enabled=true)) as usuarios_com_push,
  count(*) filter (where ba.status='active' and ba.user_id is not null and not exists(select 1 from public.push_subscriptions ps where ps.user_id=ba.user_id and ps.enabled=true)) as usuarios_sem_push
from public.beta_access ba;
