-- Resenha FC Beta 1.0 Build 124 — auditoria de usuários sem notificações
select
  coalesce(p.name, ba.email) as usuario,
  ba.email,
  ba.last_seen_at as ultimo_acesso,
  (select count(distinct gm.group_id) from public.group_members gm where gm.user_id = ba.user_id) as grupos,
  0 as aparelhos_com_push
from public.beta_access ba
left join public.profiles p on p.id = ba.user_id
where ba.status = 'active'
  and ba.user_id is not null
  and not exists (
    select 1
    from public.push_subscriptions ps
    where ps.user_id = ba.user_id
      and ps.enabled = true
  )
order by ba.last_seen_at desc nulls last, ba.email;
