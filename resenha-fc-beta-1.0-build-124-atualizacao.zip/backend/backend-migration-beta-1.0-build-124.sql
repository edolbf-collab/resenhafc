begin;

-- Resenha FC Beta 1.0 Build 124
-- Painel administrativo de status das notificações push.

create or replace function public.platform_push_status_list(p_limit integer default 500)
returns table(
  email text,
  user_id uuid,
  user_name text,
  last_seen_at timestamptz,
  groups_count bigint,
  active_push_devices bigint,
  last_push_at timestamptz,
  device_labels text[]
)
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.is_platform_admin() then raise exception 'Acesso restrito'; end if;

  return query
  with active_users as (
    select ba.email, ba.user_id, p.name as user_name, ba.last_seen_at
    from public.beta_access ba
    left join public.profiles p on p.id = ba.user_id
    where ba.status = 'active'
      and ba.user_id is not null
  )
  select
    au.email,
    au.user_id,
    au.user_name,
    au.last_seen_at,
    (select count(distinct gm.group_id) from public.group_members gm where gm.user_id = au.user_id)::bigint as groups_count,
    (select count(*) from public.push_subscriptions ps where ps.user_id = au.user_id and ps.enabled = true)::bigint as active_push_devices,
    (select max(ps.updated_at) from public.push_subscriptions ps where ps.user_id = au.user_id and ps.enabled = true) as last_push_at,
    coalesce((select array_agg(distinct ps.device_label order by ps.device_label) from public.push_subscriptions ps where ps.user_id = au.user_id and ps.enabled = true), array[]::text[]) as device_labels
  from active_users au
  order by
    (select count(*) from public.push_subscriptions ps where ps.user_id = au.user_id and ps.enabled = true) asc,
    au.last_seen_at desc nulls last,
    au.email
  limit greatest(1, least(coalesce(p_limit, 500), 1000));
end;
$$;

create or replace function public.platform_beta_summary()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if not public.is_platform_admin() then raise exception 'Acesso restrito'; end if;
  return jsonb_build_object(
    'users_total', (select count(*) from public.profiles),
    'groups_total', (select count(*) from public.groups),
    'matches_upcoming', (select count(*) from public.matches where starts_at > now()),
    'confirmations_total', (select count(*) from public.match_attendance where status = 'confirmed'),
    'push_users_active', (
      select count(*) from public.beta_access ba
      where ba.status = 'active' and ba.user_id is not null
        and exists(select 1 from public.push_subscriptions ps where ps.user_id = ba.user_id and ps.enabled = true)
    ),
    'push_users_without_active', (
      select count(*) from public.beta_access ba
      where ba.status = 'active' and ba.user_id is not null
        and not exists(select 1 from public.push_subscriptions ps where ps.user_id = ba.user_id and ps.enabled = true)
    ),
    'push_sent_total', (select coalesce(sum(push_sent_count),0) from public.announcements),
    'push_failed_total', (select coalesce(sum(push_failed_count),0) from public.announcements),
    'system_push_sent_total', (select coalesce(sum(push_sent_count),0) from public.system_announcements),
    'system_push_failed_total', (select coalesce(sum(push_failed_count),0) from public.system_announcements),
    'feedback_open', (select count(*) from public.beta_feedback where status in ('open','reviewing')),
    'errors_24h', (select count(*) from public.app_logs where severity = 'error' and created_at >= now() - interval '24 hours'),
    'error_groups_24h', (
      select count(*) from (
        select 1 from public.app_logs al
        where al.severity='error' and al.created_at >= now()-interval '24 hours'
        group by al.event_type, coalesce(nullif(al.metadata->>'message',''),'(sem mensagem)'),
                 coalesce(al.metadata->>'source',''), coalesce(al.metadata->>'line',''), coalesce(al.metadata->>'build','')
      ) grouped
    ),
    'beta_invited', (select count(*) from public.beta_access where status='invited'),
    'beta_active', (select count(*) from public.beta_access where status='active'),
    'beta_blocked', (select count(*) from public.beta_access where status='blocked'),
    'generated_at', now()
  );
end;
$$;

create or replace function public.platform_operational_export(p_days integer default 30, p_log_limit integer default 5000)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_days integer := greatest(1, least(coalesce(p_days,30),365));
  v_limit integer := greatest(100, least(coalesce(p_log_limit,5000),10000));
begin
  if not public.is_platform_admin() then raise exception 'Acesso restrito'; end if;
  return jsonb_build_object(
    'generated_at', now(),
    'period_days', v_days,
    'summary', public.platform_beta_summary(),
    'push_status', coalesce((select jsonb_agg(to_jsonb(rows) order by rows.active_push_devices, rows.email) from public.platform_push_status_list(1000) rows), '[]'::jsonb),
    'access', coalesce((
      select jsonb_agg(to_jsonb(rows) order by rows.email)
      from (
        select ba.email, ba.user_id, ba.status, ba.notes, ba.invited_at, ba.activated_at,
               ba.last_seen_at, ba.blocked_at, ba.updated_at, p.name as user_name,
               (select count(*) from public.group_members gm where gm.user_id = ba.user_id) as groups_count
        from public.beta_access ba
        left join public.profiles p on p.id = ba.user_id
      ) rows
    ), '[]'::jsonb),
    'feedback', coalesce((
      select jsonb_agg(to_jsonb(rows) order by rows.created_at desc)
      from (
        select bf.*, p.name as reporter_name, u.email::text as reporter_email, g.name as group_name
        from public.beta_feedback bf
        left join public.profiles p on p.id = bf.user_id
        left join auth.users u on u.id = bf.user_id
        left join public.groups g on g.id = bf.group_id
        where bf.created_at >= now() - make_interval(days => v_days)
        order by bf.created_at desc
        limit 2000
      ) rows
    ), '[]'::jsonb),
    'logs', coalesce((
      select jsonb_agg(to_jsonb(rows) order by rows.created_at desc)
      from (
        select al.*, p.name as user_name, u.email::text as user_email, g.name as group_name
        from public.app_logs al
        left join public.profiles p on p.id = al.user_id
        left join auth.users u on u.id = al.user_id
        left join public.groups g on g.id = al.group_id
        where al.created_at >= now() - make_interval(days => v_days)
        order by al.created_at desc
        limit v_limit
      ) rows
    ), '[]'::jsonb),
    'releases', coalesce((
      select jsonb_agg(to_jsonb(ar) order by ar.build desc)
      from public.app_releases ar
      where ar.channel = 'beta'
    ), '[]'::jsonb)
  );
end;
$$;

revoke all on function public.platform_push_status_list(integer) from public;
grant execute on function public.platform_push_status_list(integer) to authenticated;

insert into public.app_releases(channel, version, build, database_build, edge_build, active, mandatory, notes)
values ('beta', 'Beta 1.0', 124, 124, 104, true, false, 'Ícones de grupos aprovados em alta resolução e painel administrativo de usuários sem push ativo.')
on conflict (channel, build) do update set
  version = excluded.version,
  database_build = excluded.database_build,
  edge_build = excluded.edge_build,
  active = excluded.active,
  mandatory = excluded.mandatory,
  notes = excluded.notes;

update public.app_releases set active = false where channel = 'beta' and build < 124;

commit;
